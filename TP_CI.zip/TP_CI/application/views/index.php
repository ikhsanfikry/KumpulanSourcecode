<html>
<head>
<title> home </title>
<script type="text/javascript">

function validasi(form){
if (form.username.value == ""){
alert("Isi Password/Username");
form.username.focus();
return (false);
}
     
if (form.password.value == ""){
alert("Isi Password/Username");
form.password.focus();
return (false);
}
return (true);
}
</script>

<style type="text/css">
<!--
.style3 {color: #FF0000; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style4 {
	color: #FF0000;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style>
</head>
<body>
<center>
  <span class="style4">Login</span>
  <form  method="post" action="<?php echo site_url(); ?>/acc/testlogin" onSubmit="return validasi(this)">
  <table>
  <tr>
  <td><span class="style3">Username</span></td>
  <td><span class="style3">:</span></td>
  <td>
  <input name="username" type="text" id="input" size="29" />  </td>
  </tr>
	<tr>
  <td><span class="style3">Password</span></td>
  <td><span class="style3">:</span></td>
  <td>
  <input name="password" type="password" id="input" size="29" />  </td>
	</tr>
	</table>
	</fieldset>
	<br>
  <input name="Masuk" type="submit" value="Masuk" width='100' height='50' id="submit" align="absmiddle" />
  <a style='margin-left:200px'><?php echo anchor('acc/tambahAkun','register');?></a>
</form>
</fieldset>
</center>
</html>