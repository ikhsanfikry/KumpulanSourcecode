<html>
	<head>
	<title>Daftar Akun</title>
	</head>
		<body>
		<center>
		<fieldset style='margin-left:500px;margin-right:500px; '>
		<legend>Account</legend> 
		<table>

<?php
foreach ($query->result() as $acc) {
echo '<tr><td>username</td>	<td>:</td><td>'.$acc->username.'</td></tr>'
.'<tr><td>nama</td>	<td>:</td><td>'.$acc->nama.'</td></tr>'
.'<tr><td>email</td> <td>:</td><td>'.$acc->email.'</td></tr>';	
}
?>

</table>
</fieldset>
<br>
<a><?php echo anchor('acc/view','exit');?></a>
</center>
</body>
</html>