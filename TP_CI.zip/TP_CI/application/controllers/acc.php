<?php

class acc extends CI_Controller{
		
		public function __construct(){
			parent::__construct();
		}
		
		public function view(){
		$this->load->view('index');			
		}
		
		public function reg(){
		$query = $this->db->insert('tbl_log',$_POST);
		if ($query) 
		{
			redirect('acc/view');
		}
		else if(!$query){
			echo "<script>alert('isi data dengan benar');history.go(-1);</script>";
		}
		}
		
		public function tambahAkun(){
		$this->load->view('register');			
		}
		
		public function testlogin(){
		$data = array('username' => $this->input->post('username', TRUE),'password' => $this->input->post('password', TRUE));
		$query = $this->db->get_where('tbl_log',$data);
		$dat = array();
		$dat['query']=$this->db->get_where('tbl_log',$data);
		
		if ($query->num_rows() == 1) 
		{
			$this->load->view('akun',$dat);
		}
		else {
			echo "<script>alert('Login Gagal, ada kesalahan pada username/password');history.go(-1);</script>";
		}
		}
}
?>