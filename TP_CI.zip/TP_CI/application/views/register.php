
<html>
	<head>
		<title>Registrasi</title>
		<link rel="stylesheet" type="text/css" href="../css/style.css">
	    <style type="text/css">
<!--
.style3 {color: #FF0000; font-family: Verdana, Arial, Helvetica, sans-serif; }
.style4 {color: #FF0000}
-->
        </style>
</head>
	<body>
		<div class="form">
		<center>
		<fieldset style='margin-left:500px;margin-right:500px;'>
		<legend><span class="style4">FORM REGISTRASI</span> </legend>
			<form action="<?php echo site_url(); ?>/acc/reg" method="POST">
	<table >
	<tr>
	<td><span class="style3">Username</span></td>
	<td>:</td><td><input name='username' type='text' size='20'></td>
		</tr>
	<tr>
	<td><span class="style3">Password</span></td>
	<td>:</td><td><input  name='password' type='password' size='20'></td>
		</tr>
	<tr>
	<td><span class="style3">Nama</span></td>
	<td>:</td>
	<td><input  name='nama' type='text' size='30'></td>
	</tr>
	<tr>
	<td><span class="style3">Email</span></td>
	<td>:</td><td><input  name='email' type='email' size='30'></td>
		</tr>
	</table>
	</fieldset>
	<br>
	<a style='margin-left:150px'>
	<?php echo anchor('acc/view','akun');?></a>
	<input style='margin-left:350px' type='submit' value='daftar'/>
	</form>
			<center>
	</div>
	</body>
</html>